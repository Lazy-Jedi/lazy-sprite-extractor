#if UNITY_EDITOR
using System.Collections.ObjectModel;
using System.IO;
using UnityEditor;
using UnityEditor.U2D.Aseprite;
using UnityEngine;

public static class AsepriteSpriteExtractor
{
    [MenuItem("Assets/Extract/Aseprite/Extract Sprites", priority = 10)]
    public static void ExtractFromAseprite()
    {
        Object selectedObject = Selection.activeObject;
        string path = AssetDatabase.GetAssetPath(selectedObject);
        string extension = Path.GetExtension(path);
        if (!extension.Equals(".ase") && !path.EndsWith(".aseprite"))
            return;

        AsepriteFile asepriteFile = AsepriteReader.ReadFile(path);
        if (asepriteFile is null)
            return;

        Debug.unityLogger.Log($"Aseprite File - Width: {asepriteFile.width} ; Height: {asepriteFile.height} ; Frames: {asepriteFile.noOfFrames}");

        string filename = Path.GetFileNameWithoutExtension(path);
        string directory = Path.GetDirectoryName(path);

        int noOfFrames = asepriteFile.noOfFrames;

        ReadOnlyCollection<FrameData> frames = asepriteFile.frameData;
        for (int index = 0; index < noOfFrames; index++)
        {
            FrameData frameData = frames[index];
            foreach (BaseChunk baseChunk in frameData.chunks)
            {
                if (baseChunk.chunkType != ChunkTypes.Cell)
                    continue;

                using (CellChunk cellChunk = baseChunk as CellChunk)
                {
                    if (cellChunk == null)
                        continue;

                    Texture2D newTexture2D = new Texture2D(cellChunk.width, cellChunk.height);
                    newTexture2D.SetPixels32(cellChunk.image.ToArray());
                    newTexture2D.Apply();
                    byte[] data = newTexture2D.EncodeToPNG();
                    if (!Directory.Exists($"{directory}/{filename}/"))
                    {
                        Directory.CreateDirectory($"{directory}/{filename}/");
                    }

                    File.WriteAllBytes($"{directory}/{filename}/{filename}_{index}.png", data);
                }
            }

            frameData.Dispose();
        }

        AssetDatabase.Refresh();
    }
}
#endif